import { Doc, Id } from "../../convex/_generated/dataModel";

// Core entity types
export type User = Doc<"users">;
export type Creator = Doc<"creators">;
export type Vault = Doc<"vaults">;
export type Library = Doc<"libraries">;
export type Content = Doc<"content">;
export type Purchase = Doc<"purchases">;
export type VaultSubscription = Doc<"vaultSubscriptions">;
export type Treasure = Doc<"treasures">;
export type PointTransaction = Doc<"pointTransactions">;
export type VaultTour = Doc<"vaultTours">;
export type NetworkConnection = Doc<"networkConnections">;
export type NetworkBenefit = Doc<"networkBenefits">;
export type ScrapbookPhoto = Doc<"scrapbookPhotos">;
export type Offer = Doc<"offers">;
export type OfferUsage = Doc<"offerUsages">;
export type Achievement = Doc<"achievements">;
export type UserAchievement = Doc<"userAchievements">;
export type UserStreak = Doc<"userStreaks">;
export type SecurityEvent = Doc<"securityEvents">;

// Extended types with relations
export interface CreatorWithStats extends Creator {
  vaultCount: number;
  totalSubscribers: number;
  totalRevenue: number;
  averageRating: number;
}

export interface VaultWithDetails extends Vault {
  creator: Creator;
  subscriberCount: number;
  libraryCount: number;
  totalContent: number;
  isSubscribed?: boolean;
}

export interface ContentWithDetails extends Content {
  library: Library;
  creator: Creator;
  vault: Vault;
  isPurchased?: boolean;
  hasAccess?: boolean;
}

export interface PurchaseWithDetails extends Purchase {
  content?: Content;
  vault?: Vault;
  user: User;
  treasuresEarned: Treasure[];
}

// UI Component Props Types
export interface VaultCardProps {
  vault: VaultWithDetails;
  onSubscribe?: (vaultId: Id<"vaults">) => void;
  onViewDetails?: (vaultId: Id<"vaults">) => void;
  className?: string;
}

export interface ContentPlayerProps {
  content: ContentWithDetails;
  onPurchase?: (contentId: Id<"content">) => void;
  onComplete?: (contentId: Id<"content">) => void;
  autoPlay?: boolean;
  className?: string;
}

export interface TreasureDisplayProps {
  treasures: Treasure[];
  showValues?: boolean;
  interactive?: boolean;
  onTreasureClick?: (treasure: Treasure) => void;
  className?: string;
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
  };
}

// Payment Types
export interface PaymentIntent {
  clientSecret: string;
  paymentIntentId: string;
  amount: number;
  currency: string;
}

export interface SubscriptionDetails {
  subscriptionId: string;
  status: "active" | "cancelled" | "expired";
  currentPeriodEnd: number;
  cancelAtPeriodEnd: boolean;
}

// Gamification Types
export interface TreasureReward {
  type: Treasure["type"];
  rarity: Treasure["rarity"];
  value: number;
  probability: number;
}

export interface LoyaltyPointsCalculation {
  basePoints: number;
  multiplier: number;
  bonusPoints: number;
  totalPoints: number;
  source: string;
}

// Security Types
export interface SecurityContext {
  userId: Id<"users">;
  ipAddress: string;
  userAgent: string;
  deviceFingerprint?: string;
  sessionId: string;
}

export interface AccessControl {
  canView: boolean;
  canPurchase: boolean;
  canDownload: boolean;
  reason?: string;
}

// Search and Filter Types
export interface SearchFilters {
  query?: string;
  creatorId?: Id<"creators">;
  priceRange?: {
    min: number;
    max: number;
  };
  category?: string;
  sortBy?: "newest" | "oldest" | "price_low" | "price_high" | "popular";
  limit?: number;
  offset?: number;
}

export interface VaultFilters extends SearchFilters {
  subscriptionType?: Vault["subscriptionType"];
  accessLevel?: Vault["accessLevel"];
}

// Form Types
export interface CreateVaultForm {
  title: string;
  description: string;
  subscriptionPrice: number;
  subscriptionType: Vault["subscriptionType"];
  accessLevel: Vault["accessLevel"];
}

export interface CreateContentForm {
  title: string;
  description?: string;
  price: number;
  videoFile?: File;
  thumbnailFile?: File;
  libraryId: Id<"libraries">;
}

export interface UpdateProfileForm {
  name?: string;
  bio?: string;
  avatarFile?: File;
}

// Analytics Types
export interface VaultAnalytics {
  vaultId: Id<"vaults">;
  views: number;
  subscriptions: number;
  revenue: number;
  conversionRate: number;
  topContent: ContentWithDetails[];
  revenueByMonth: Array<{
    month: string;
    revenue: number;
    subscriptions: number;
  }>;
}

export interface CreatorAnalytics {
  creatorId: Id<"creators">;
  totalRevenue: number;
  totalSubscribers: number;
  totalViews: number;
  vaultPerformance: VaultAnalytics[];
  loyaltyPointsDistributed: number;
  treasuresMinted: number;
}

// Network Types
export interface NetworkRecommendation {
  recommendedCreator: Creator;
  endorsementText: string;
  benefitPercentage: number;
  totalEarnings: number;
  status: NetworkConnection["status"];
}

export interface NetworkStats {
  totalConnections: number;
  totalEarnings: number;
  topPerformingConnections: NetworkRecommendation[];
  monthlyEarnings: Array<{
    month: string;
    earnings: number;
  }>;
}

// Tour Types
export interface TourSegment {
  timestamp: number;
  title: string;
  description: string;
  position: {
    x: number;
    y: number;
    z: number;
  };
}

export interface TourConfig {
  autoPlay: boolean;
  showMinimap: boolean;
  allowSkip: boolean;
}

// Error Types
export class AppError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number = 500
  ) {
    super(message);
    this.name = "AppError";
  }
}

export class ValidationError extends AppError {
  constructor(message: string, public field?: string) {
    super(message, "VALIDATION_ERROR", 400);
  }
}

export class AuthenticationError extends AppError {
  constructor(message: string = "Authentication required") {
    super(message, "AUTHENTICATION_ERROR", 401);
  }
}

export class AuthorizationError extends AppError {
  constructor(message: string = "Access denied") {
    super(message, "AUTHORIZATION_ERROR", 403);
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string = "Resource") {
    super(`${resource} not found`, "NOT_FOUND_ERROR", 404);
  }
}

export class PaymentError extends AppError {
  constructor(message: string) {
    super(message, "PAYMENT_ERROR", 402);
  }
}

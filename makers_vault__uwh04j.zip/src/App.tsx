import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { VaultGrid } from "./components/features/vault/VaultGrid";
import { UserDashboard } from "./components/features/dashboard/UserDashboard";
import { useState } from "react";
import { Id } from "../convex/_generated/dataModel";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <header className="sticky top-0 z-50 bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                </svg>
              </div>
              <h1 className="text-xl font-bold text-white">Maker's Vault</h1>
            </div>
            <SignOutButton />
          </div>
        </div>
      </header>

      <main className="flex-1">
        <Content />
      </main>
      
      <Toaster 
        theme="dark"
        position="bottom-right"
        toastOptions={{
          style: {
            background: 'rgba(0, 0, 0, 0.8)',
            color: 'white',
            border: '1px solid rgba(255, 255, 255, 0.1)',
          },
        }}
      />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const [searchQuery, setSearchQuery] = useState("");

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-2 border-yellow-400 border-t-transparent"></div>
      </div>
    );
  }

  const handleSubscribe = async (vaultId: Id<"vaults">) => {
    // In a real app, this would integrate with Stripe
    console.log("Subscribing to vault:", vaultId);
    // For demo purposes, we'll just log it
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Unauthenticated>
        <div className="text-center py-20">
          <div className="mb-8">
            <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 mb-4">
              Maker's Vault
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Discover exclusive content from your favorite creators. Unlock treasures, build networks, and join a community of makers.
            </p>
          </div>
          
          <div className="max-w-md mx-auto">
            <SignInForm />
          </div>
          
          {/* Preview of vaults for unauthenticated users */}
          <div className="mt-16">
            <h2 className="text-2xl font-semibold text-white mb-8">Featured Vaults</h2>
            <VaultGrid limit={6} className="opacity-75" />
            <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent pointer-events-none"></div>
          </div>
        </div>
      </Unauthenticated>

      <Authenticated>
        <UserDashboard />
        <div className="space-y-8 hidden">
          {/* Welcome Section */}
          <div className="text-center py-12">
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 mb-4">
              Welcome back, {loggedInUser?.name || "Treasure Hunter"}!
            </h1>
            <p className="text-lg text-gray-300">
              Ready to discover new vaults and collect treasures?
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-3 border border-white/20 rounded-lg bg-white/10 backdrop-blur-sm text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                placeholder="Search for vaults, creators, or content..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard
              title="Vaults Discovered"
              value="12"
              icon="🏛️"
              gradient="from-blue-500 to-purple-600"
            />
            <StatCard
              title="Treasures Collected"
              value="47"
              icon="💎"
              gradient="from-yellow-500 to-orange-600"
            />
            <StatCard
              title="Loyalty Points"
              value="2,340"
              icon="⭐"
              gradient="from-green-500 to-teal-600"
            />
            <StatCard
              title="Network Size"
              value="8"
              icon="🌐"
              gradient="from-pink-500 to-rose-600"
            />
          </div>

          {/* Vault Grid */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-semibold text-white">Explore Vaults</h2>
              <div className="flex space-x-2">
                <button className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg text-white hover:bg-white/20 transition-colors">
                  All
                </button>
                <button className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg text-white hover:bg-white/20 transition-colors">
                  Premium
                </button>
                <button className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg text-white hover:bg-white/20 transition-colors">
                  New
                </button>
              </div>
            </div>
            
            <VaultGrid 
              searchQuery={searchQuery || undefined}
              onSubscribe={handleSubscribe}
            />
          </div>
        </div>
      </Authenticated>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  icon: string;
  gradient: string;
}

function StatCard({ title, value, icon, gradient }: StatCardProps) {
  return (
    <div className={`bg-gradient-to-r ${gradient} rounded-lg p-6 text-white`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm opacity-90">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
        <div className="text-3xl opacity-80">{icon}</div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Treasure } from "@/types";

interface TreasureDisplayProps {
  treasures: Treasure[];
  showValues?: boolean;
  interactive?: boolean;
  onTreasureClick?: (treasure: Treasure) => void;
  className?: string;
}

export function TreasureDisplay({ 
  treasures, 
  showValues = true, 
  interactive = true, 
  onTreasureClick,
  className = "" 
}: TreasureDisplayProps) {
  const [hoveredTreasure, setHoveredTreasure] = useState<string | null>(null);

  const getTreasureIcon = (type: string) => {
    switch (type) {
      case "coin":
        return "🪙";
      case "gem":
        return "💎";
      case "artifact":
        return "🏺";
      case "scroll":
        return "📜";
      case "crown":
        return "👑";
      default:
        return "✨";
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common":
        return "from-gray-400 to-gray-600";
      case "rare":
        return "from-blue-400 to-blue-600";
      case "epic":
        return "from-purple-400 to-purple-600";
      case "legendary":
        return "from-yellow-400 to-orange-500";
      default:
        return "from-gray-400 to-gray-600";
    }
  };

  const getRarityGlow = (rarity: string) => {
    switch (rarity) {
      case "common":
        return "shadow-gray-500/20";
      case "rare":
        return "shadow-blue-500/30";
      case "epic":
        return "shadow-purple-500/40";
      case "legendary":
        return "shadow-yellow-500/50";
      default:
        return "shadow-gray-500/20";
    }
  };

  if (treasures.length === 0) {
    return (
      <div className={`text-center py-8 ${className}`}>
        <div className="w-16 h-16 mx-auto mb-4 bg-white/10 rounded-full flex items-center justify-center">
          <span className="text-2xl">💎</span>
        </div>
        <h3 className="text-lg font-medium text-white mb-2">No Treasures Yet</h3>
        <p className="text-gray-400">
          Start purchasing content to collect your first treasures!
        </p>
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 ${className}`}>
      {treasures.map((treasure) => (
        <div
          key={treasure._id}
          className={`relative group cursor-pointer transition-all duration-300 ${
            interactive ? "hover:scale-110" : ""
          }`}
          onMouseEnter={() => setHoveredTreasure(treasure._id)}
          onMouseLeave={() => setHoveredTreasure(null)}
          onClick={() => interactive && onTreasureClick?.(treasure)}
        >
          {/* Treasure Container */}
          <div className={`
            relative w-20 h-20 mx-auto rounded-xl bg-gradient-to-br ${getRarityColor(treasure.rarity)}
            border border-white/20 ${getRarityGlow(treasure.rarity)}
            flex items-center justify-center transition-all duration-300
            ${hoveredTreasure === treasure._id ? "shadow-lg scale-105" : ""}
          `}>
            {/* Treasure Icon */}
            <span className="text-2xl animate-pulse">
              {getTreasureIcon(treasure.type)}
            </span>

            {/* Rarity Indicator */}
            <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-white/20 flex items-center justify-center">
              <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${getRarityColor(treasure.rarity)}`}></div>
            </div>

            {/* Glow Effect */}
            {treasure.rarity === "legendary" && (
              <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-yellow-400/20 to-orange-500/20 animate-pulse"></div>
            )}
          </div>

          {/* Treasure Info */}
          <div className="mt-2 text-center">
            <p className="text-xs font-medium text-white capitalize">
              {treasure.rarity} {treasure.type}
            </p>
            {showValues && (
              <p className="text-xs text-gray-400">
                {treasure.value.toLocaleString()} pts
              </p>
            )}
          </div>

          {/* Hover Tooltip */}
          {hoveredTreasure === treasure._id && (
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 z-10">
              <div className="bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2 text-xs text-white whitespace-nowrap">
                <p className="font-medium">{treasure.rarity} {treasure.type}</p>
                <p className="text-gray-300">Worth {treasure.value} points</p>
                <p className="text-gray-400">From: {treasure.earnedFrom}</p>
                {/* Arrow */}
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/80"></div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

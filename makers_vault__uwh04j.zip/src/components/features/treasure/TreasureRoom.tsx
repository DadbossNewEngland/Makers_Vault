import { useState } from "react";
import { TreasureDisplay } from "./TreasureDisplay";
import { Treasure } from "@/types";

interface TreasureRoomProps {
  treasures: Treasure[];
  totalValue: number;
  className?: string;
}

export function TreasureRoom({ treasures, totalValue, className = "" }: TreasureRoomProps) {
  const [selectedTreasure, setSelectedTreasure] = useState<Treasure | null>(null);

  const getRarityStats = () => {
    const stats = treasures.reduce((acc, treasure) => {
      acc[treasure.rarity] = (acc[treasure.rarity] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return [
      { rarity: "common", count: stats.common || 0, color: "text-gray-400" },
      { rarity: "rare", count: stats.rare || 0, color: "text-blue-400" },
      { rarity: "epic", count: stats.epic || 0, color: "text-purple-400" },
      { rarity: "legendary", count: stats.legendary || 0, color: "text-yellow-400" },
    ];
  };

  const handleTreasureClick = (treasure: Treasure) => {
    setSelectedTreasure(treasure);
  };

  return (
    <div className={`bg-gradient-to-br from-purple-900/50 via-blue-900/50 to-indigo-900/50 rounded-xl p-6 border border-white/10 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Treasure Room</h2>
          <p className="text-gray-400">Your collected treasures and achievements</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
            {totalValue.toLocaleString()}
          </div>
          <div className="text-sm text-gray-400">Total Value</div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {getRarityStats().map((stat) => (
          <div key={stat.rarity} className="text-center">
            <div className={`text-2xl font-bold ${stat.color}`}>
              {stat.count}
            </div>
            <div className="text-xs text-gray-400 capitalize">
              {stat.rarity}
            </div>
          </div>
        ))}
      </div>

      {/* Treasure Display */}
      <TreasureDisplay
        treasures={treasures}
        onTreasureClick={handleTreasureClick}
        className="mb-6"
      />

      {/* Achievement Progress */}
      <div className="border-t border-white/10 pt-6">
        <h3 className="text-lg font-semibold text-white mb-4">Collection Progress</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300">Treasure Collector</span>
            <div className="flex items-center space-x-2">
              <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-500"
                  style={{ width: `${Math.min((treasures.length / 10) * 100, 100)}%` }}
                ></div>
              </div>
              <span className="text-xs text-gray-400">{treasures.length}/10</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300">Legendary Hunter</span>
            <div className="flex items-center space-x-2">
              <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-purple-400 to-pink-500 transition-all duration-500"
                  style={{ 
                    width: `${Math.min((treasures.filter(t => t.rarity === "legendary").length / 3) * 100, 100)}%` 
                  }}
                ></div>
              </div>
              <span className="text-xs text-gray-400">
                {treasures.filter(t => t.rarity === "legendary").length}/3
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Treasure Detail Modal */}
      {selectedTreasure && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gradient-to-br from-gray-900 to-black rounded-xl p-6 max-w-md w-full mx-4 border border-white/20">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white capitalize">
                {selectedTreasure.rarity} {selectedTreasure.type}
              </h3>
              <button
                onClick={() => setSelectedTreasure(null)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="text-center mb-4">
              <div className="w-24 h-24 mx-auto mb-4 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
                <span className="text-4xl">
                  {selectedTreasure.type === "coin" ? "🪙" : 
                   selectedTreasure.type === "gem" ? "💎" :
                   selectedTreasure.type === "artifact" ? "🏺" :
                   selectedTreasure.type === "scroll" ? "📜" :
                   selectedTreasure.type === "crown" ? "👑" : "✨"}
                </span>
              </div>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Value:</span>
                <span className="text-white font-medium">{selectedTreasure.value.toLocaleString()} points</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Earned From:</span>
                <span className="text-white font-medium capitalize">{selectedTreasure.earnedFrom}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Minted:</span>
                <span className="text-white font-medium">
                  {new Date(selectedTreasure.mintedAt).toLocaleDateString()}
                </span>
              </div>
            </div>

            <div className="mt-6 p-3 bg-white/5 rounded-lg">
              <p className="text-xs text-gray-400 text-center">
                This treasure is cryptographically secured and ready for future blockchain integration.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

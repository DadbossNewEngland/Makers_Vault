import { useQuery } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import { VaultCard } from "@/components/ui/VaultCard";
import { VaultWithDetails } from "@/types";
import { Id } from "../../../../convex/_generated/dataModel";

interface VaultGridProps {
  searchQuery?: string;
  creatorId?: Id<"creators">;
  limit?: number;
  onSubscribe?: (vaultId: Id<"vaults">) => void;
  className?: string;
}

export function VaultGrid({ 
  searchQuery, 
  creatorId, 
  limit = 20, 
  onSubscribe,
  className = "" 
}: VaultGridProps) {
  const vaults = useQuery(api.vaults.list, {
    search: searchQuery,
    creatorId,
    limit,
  });

  if (vaults === undefined) {
    return (
      <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 ${className}`}>
        {Array.from({ length: 6 }).map((_, i) => (
          <VaultCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (vaults.length === 0) {
    return (
      <div className={`text-center py-16 ${className}`}>
        <div className="w-32 h-32 mx-auto mb-6 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-sm">
          <svg className="w-16 h-16 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
        </div>
        <h3 className="text-2xl font-semibold text-white mb-3">No vaults found</h3>
        <p className="text-gray-400 text-lg max-w-md mx-auto">
          {searchQuery 
            ? `No vaults match your search for "${searchQuery}". Try different keywords or explore all vaults.`
            : "There are no vaults available at the moment. Check back soon for new content!"
          }
        </p>
        {searchQuery && (
          <button 
            onClick={() => window.location.reload()}
            className="mt-6 px-6 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 rounded-lg text-white font-medium transition-all duration-200 transform hover:scale-105"
          >
            Explore All Vaults
          </button>
        )}
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 ${className}`}>
      {vaults.map((vault) => (
        <VaultCard
          key={vault._id}
          vault={vault as VaultWithDetails}
          onSubscribe={onSubscribe}
        />
      ))}
    </div>
  );
}

function VaultCardSkeleton() {
  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl overflow-hidden border border-white/20 animate-pulse">
      <div className="p-6">
        {/* Header skeleton */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="h-6 bg-white/20 rounded mb-2"></div>
            <div className="h-4 bg-white/20 rounded w-3/4"></div>
          </div>
          <div className="ml-4 w-20 h-6 bg-white/20 rounded-full"></div>
        </div>

        {/* Creator info skeleton */}
        <div className="flex items-center mb-4">
          <div className="w-10 h-10 bg-white/20 rounded-full mr-3"></div>
          <div>
            <div className="h-4 bg-white/20 rounded w-24 mb-1"></div>
            <div className="h-3 bg-white/20 rounded w-16"></div>
          </div>
        </div>

        {/* Stats skeleton */}
        <div className="flex items-center justify-between text-sm mb-6">
          <div className="h-4 bg-white/20 rounded w-20"></div>
          <div className="h-4 bg-white/20 rounded w-20"></div>
          <div className="h-4 bg-white/20 rounded w-20"></div>
        </div>

        {/* Pricing skeleton */}
        <div className="flex items-center justify-between">
          <div className="h-8 bg-white/20 rounded w-24"></div>
          <div className="h-10 bg-white/20 rounded w-28"></div>
        </div>
      </div>

      {/* Shimmer effect */}
      <div className="absolute inset-0 -skew-x-12 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer"></div>
    </div>
  );
}

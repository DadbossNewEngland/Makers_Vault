import { useQuery } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import { TreasureRoom } from "../treasure/TreasureRoom";
import { LoyaltyDashboard } from "../gamification/LoyaltyDashboard";
import { VaultGrid } from "../vault/VaultGrid";

export function UserDashboard() {
  const user = useQuery(api.auth.loggedInUser);
  const userSubscriptions = useQuery(api.vaults.getUserSubscriptions);
  
  // Mock data for demonstration
  const mockTreasures = [
    {
      _id: "1" as any,
      _creationTime: Date.now(),
      userId: user?._id || ("" as any),
      type: "coin" as const,
      rarity: "common" as const,
      value: 100,
      mintSignature: "sig1",
      earnedFrom: "purchase",
      mintedAt: Date.now(),
    },
    {
      _id: "2" as any, 
      _creationTime: Date.now(),
      userId: user?._id || ("" as any),
      type: "gem" as const,
      rarity: "rare" as const,
      value: 500,
      mintSignature: "sig2",
      earnedFrom: "achievement",
      mintedAt: Date.now(),
    },
    {
      _id: "3" as any,
      _creationTime: Date.now(), 
      userId: user?._id || ("" as any),
      type: "crown" as const,
      rarity: "legendary" as const,
      value: 2000,
      mintSignature: "sig3",
      earnedFrom: "special_event",
      mintedAt: Date.now(),
    },
  ];

  const totalTreasureValue = mockTreasures.reduce((sum, treasure) => sum + treasure.value, 0);

  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-2 border-yellow-400 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Section */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 mb-4">
          Welcome back, {user.name || "Treasure Hunter"}!
        </h1>
        <p className="text-lg text-gray-300">
          Continue your journey and discover new treasures
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">Active Subscriptions</p>
              <p className="text-2xl font-bold">{userSubscriptions?.length || 0}</p>
            </div>
            <div className="text-3xl opacity-80">🏛️</div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-green-500 to-teal-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">Treasures Collected</p>
              <p className="text-2xl font-bold">{mockTreasures.length}</p>
            </div>
            <div className="text-3xl opacity-80">💎</div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-yellow-500 to-orange-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">Total Value</p>
              <p className="text-2xl font-bold">{totalTreasureValue.toLocaleString()}</p>
            </div>
            <div className="text-3xl opacity-80">⭐</div>
          </div>
        </div>
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Loyalty Dashboard */}
        <LoyaltyDashboard 
          points={2340}
          multiplier={10}
          nextTierPoints={5000}
        />

        {/* Treasure Room */}
        <TreasureRoom 
          treasures={mockTreasures}
          totalValue={totalTreasureValue}
        />
      </div>

      {/* My Subscriptions */}
      {userSubscriptions && userSubscriptions.length > 0 && (
        <div>
          <h2 className="text-2xl font-semibold text-white mb-6">My Subscriptions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userSubscriptions.map((subscription) => (
              <div key={subscription._id} className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <h3 className="text-lg font-semibold text-white mb-2">
                  {subscription.vault?.title}
                </h3>
                <p className="text-gray-300 text-sm mb-4">
                  by {subscription.creator?.name}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">
                    Expires: {new Date(subscription.expiresAt).toLocaleDateString()}
                  </span>
                  <span className="inline-flex items-center px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                    Active
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommended Vaults */}
      <div>
        <h2 className="text-2xl font-semibold text-white mb-6">Discover New Vaults</h2>
        <VaultGrid limit={6} />
      </div>
    </div>
  );
}

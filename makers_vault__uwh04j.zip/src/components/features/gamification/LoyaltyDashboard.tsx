interface LoyaltyDashboardProps {
  points: number;
  multiplier: number;
  nextTierPoints: number;
  className?: string;
}

export function LoyaltyDashboard({ 
  points, 
  multiplier = 10, 
  nextTierPoints = 5000,
  className = "" 
}: LoyaltyDashboardProps) {
  const progressPercentage = (points / nextTierPoints) * 100;

  const tiers = [
    { name: "Bronze Explorer", points: 0, color: "from-amber-600 to-amber-800", icon: "🥉" },
    { name: "Silver Adventurer", points: 1000, color: "from-gray-400 to-gray-600", icon: "🥈" },
    { name: "Gold Collector", points: 5000, color: "from-yellow-400 to-yellow-600", icon: "🥇" },
    { name: "Platinum Master", points: 15000, color: "from-blue-400 to-blue-600", icon: "💎" },
    { name: "Diamond Legend", points: 50000, color: "from-purple-400 to-purple-600", icon: "👑" },
  ];

  const currentTier = tiers.reduce((prev, curr) => 
    points >= curr.points ? curr : prev
  );

  const nextTier = tiers.find(tier => tier.points > points);

  return (
    <div className={`bg-gradient-to-br from-indigo-900/50 via-purple-900/50 to-pink-900/50 rounded-xl p-6 border border-white/10 ${className}`}>
      {/* Header */}
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">Loyalty Points</h2>
        <div className="flex items-center justify-center space-x-2">
          <span className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
            {points.toLocaleString()}
          </span>
          <div className="text-sm text-gray-400">
            <div>×{multiplier} Multiplier</div>
            <div className="text-xs">Always Active</div>
          </div>
        </div>
      </div>

      {/* Current Tier */}
      <div className="text-center mb-6">
        <div className={`inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r ${currentTier.color} text-white font-medium mb-2`}>
          <span className="mr-2">{currentTier.icon}</span>
          {currentTier.name}
        </div>
        <p className="text-sm text-gray-400">
          {nextTier ? `${(nextTier.points - points).toLocaleString()} points to ${nextTier.name}` : "Maximum tier reached!"}
        </p>
      </div>

      {/* Progress Bar */}
      {nextTier && (
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-400 mb-2">
            <span>{currentTier.name}</span>
            <span>{nextTier.name}</span>
          </div>
          <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-1000 ease-out"
              style={{ width: `${Math.min(progressPercentage, 100)}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>{currentTier.points.toLocaleString()}</span>
            <span>{nextTier.points.toLocaleString()}</span>
          </div>
        </div>
      )}

      {/* Benefits */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-white">Your Benefits</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
            <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
              <span className="text-green-400">⚡</span>
            </div>
            <div>
              <div className="text-sm font-medium text-white">10× Points</div>
              <div className="text-xs text-gray-400">On every purchase</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
            <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center">
              <span className="text-purple-400">💎</span>
            </div>
            <div>
              <div className="text-sm font-medium text-white">Treasure Drops</div>
              <div className="text-xs text-gray-400">Guaranteed rewards</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
            <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center">
              <span className="text-blue-400">🎯</span>
            </div>
            <div>
              <div className="text-sm font-medium text-white">Exclusive Access</div>
              <div className="text-xs text-gray-400">Premium content</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
            <div className="w-8 h-8 bg-orange-500/20 rounded-full flex items-center justify-center">
              <span className="text-orange-400">🔗</span>
            </div>
            <div>
              <div className="text-sm font-medium text-white">Network Bonus</div>
              <div className="text-xs text-gray-400">Creator connections</div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="mt-6 pt-6 border-t border-white/10">
        <h3 className="text-lg font-semibold text-white mb-3">Recent Earnings</h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Content Purchase</span>
            <span className="text-green-400 font-medium">+299 pts</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Daily Bonus</span>
            <span className="text-green-400 font-medium">+50 pts</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Achievement Unlock</span>
            <span className="text-green-400 font-medium">+100 pts</span>
          </div>
        </div>
      </div>
    </div>
  );
}

import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // User profiles and creator data
  creators: defineTable({
    userId: v.id("users"),
    name: v.string(),
    bio: v.optional(v.string()),
    avatar: v.optional(v.id("_storage")),
    verified: v.boolean(),
    loyaltyBalance: v.number(),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_verified", ["verified"]),

  // Vaults - secure content containers
  vaults: defineTable({
    creatorId: v.id("creators"),
    title: v.string(),
    description: v.string(),
    subscriptionPrice: v.number(),
    subscriptionType: v.union(v.literal("monthly"), v.literal("yearly"), v.literal("lifetime")),
    isActive: v.boolean(),
    accessLevel: v.union(v.literal("public"), v.literal("premium"), v.literal("exclusive")),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_creator", ["creatorId"])
    .index("by_active", ["isActive"])
    .searchIndex("search_vaults", {
      searchField: "title",
      filterFields: ["creatorId", "isActive"]
    }),

  // Content libraries within vaults
  libraries: defineTable({
    vaultId: v.id("vaults"),
    title: v.string(),
    description: v.optional(v.string()),
    price: v.number(),
    order: v.number(),
    createdAt: v.number(),
  })
    .index("by_vault", ["vaultId"])
    .index("by_vault_order", ["vaultId", "order"]),

  // Individual content items
  content: defineTable({
    libraryId: v.id("libraries"),
    creatorId: v.id("creators"),
    title: v.string(),
    description: v.optional(v.string()),
    videoUrl: v.optional(v.string()),
    thumbnailId: v.optional(v.id("_storage")),
    price: v.number(),
    duration: v.optional(v.number()),
    isActive: v.boolean(),
    viewCount: v.number(),
    createdAt: v.number(),
  })
    .index("by_library", ["libraryId"])
    .index("by_creator", ["creatorId"])
    .index("by_active", ["isActive"])
    .searchIndex("search_content", {
      searchField: "title",
      filterFields: ["creatorId", "isActive"]
    }),

  // Purchase records with security tracking
  purchases: defineTable({
    userId: v.id("users"),
    contentId: v.optional(v.id("content")),
    vaultId: v.optional(v.id("vaults")),
    amount: v.number(),
    stripePaymentId: v.string(),
    loyaltyPointsEarned: v.number(),
    ipAddress: v.string(),
    deviceFingerprint: v.optional(v.string()),
    fraudScore: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_content", ["contentId"])
    .index("by_vault", ["vaultId"])
    .index("by_stripe_payment", ["stripePaymentId"]),

  // Vault subscriptions
  vaultSubscriptions: defineTable({
    userId: v.id("users"),
    vaultId: v.id("vaults"),
    status: v.union(v.literal("active"), v.literal("cancelled"), v.literal("expired")),
    stripeSubscriptionId: v.string(),
    expiresAt: v.number(),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_vault", ["vaultId"])
    .index("by_status", ["status"])
    .index("by_stripe_subscription", ["stripeSubscriptionId"]),

  // Gamification - Treasures
  treasures: defineTable({
    userId: v.id("users"),
    type: v.union(v.literal("coin"), v.literal("gem"), v.literal("artifact"), v.literal("scroll"), v.literal("crown")),
    rarity: v.union(v.literal("common"), v.literal("rare"), v.literal("epic"), v.literal("legendary")),
    value: v.number(),
    mintSignature: v.string(),
    purchaseId: v.optional(v.id("purchases")),
    earnedFrom: v.string(),
    mintedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_rarity", ["rarity"])
    .index("by_type", ["type"])
    .index("by_mint_signature", ["mintSignature"]),

  // Point transactions for loyalty system
  pointTransactions: defineTable({
    userId: v.id("users"),
    purchaseId: v.optional(v.id("purchases")),
    amount: v.number(),
    multiplier: v.number(),
    source: v.string(),
    hash: v.string(),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_source", ["source"])
    .index("by_hash", ["hash"]),

  // Vault tours for 3D navigation
  vaultTours: defineTable({
    vaultId: v.id("vaults"),
    title: v.string(),
    videoUrl: v.string(),
    segments: v.array(v.object({
      timestamp: v.number(),
      title: v.string(),
      description: v.string(),
      position: v.object({
        x: v.number(),
        y: v.number(),
        z: v.number(),
      }),
    })),
    config: v.object({
      autoPlay: v.boolean(),
      showMinimap: v.boolean(),
      allowSkip: v.boolean(),
    }),
    isActive: v.boolean(),
    createdAt: v.number(),
  })
    .index("by_vault", ["vaultId"])
    .index("by_active", ["isActive"]),

  // Creator network connections
  networkConnections: defineTable({
    recommenderId: v.id("creators"),
    recommendedCreatorId: v.id("creators"),
    endorsementText: v.string(),
    status: v.union(v.literal("pending"), v.literal("verified"), v.literal("rejected")),
    benefitPercentage: v.number(),
    createdAt: v.number(),
  })
    .index("by_recommender", ["recommenderId"])
    .index("by_recommended", ["recommendedCreatorId"])
    .index("by_status", ["status"]),

  // Network benefits tracking
  networkBenefits: defineTable({
    connectionId: v.id("networkConnections"),
    purchaseId: v.id("purchases"),
    recommenderId: v.id("creators"),
    amount: v.number(),
    type: v.string(),
    hash: v.string(),
    createdAt: v.number(),
  })
    .index("by_recommender", ["recommenderId"])
    .index("by_purchase", ["purchaseId"])
    .index("by_hash", ["hash"]),

  // Creator scrapbook photos
  scrapbookPhotos: defineTable({
    creatorId: v.id("creators"),
    imageId: v.id("_storage"),
    caption: v.string(),
    order: v.number(),
    createdAt: v.number(),
  })
    .index("by_creator", ["creatorId"])
    .index("by_creator_order", ["creatorId", "order"]),

  // Promotional offers
  offers: defineTable({
    code: v.string(),
    title: v.string(),
    description: v.string(),
    discountType: v.union(v.literal("percentage"), v.literal("fixed_amount")),
    discountValue: v.number(),
    conditions: v.object({
      minPurchaseAmount: v.optional(v.number()),
      validForCreators: v.optional(v.array(v.id("creators"))),
      validForVaults: v.optional(v.array(v.id("vaults"))),
    }),
    maxUsesPerUser: v.number(),
    usageCount: v.number(),
    isActive: v.boolean(),
    expiresAt: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_code", ["code"])
    .index("by_active", ["isActive"]),

  // Offer usage tracking
  offerUsages: defineTable({
    userId: v.id("users"),
    offerId: v.id("offers"),
    discount: v.number(),
    usedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_offer", ["offerId"]),

  // Achievements system
  achievements: defineTable({
    key: v.string(),
    title: v.string(),
    description: v.string(),
    badgeImageId: v.optional(v.id("_storage")),
    points: v.number(),
    isActive: v.boolean(),
    createdAt: v.number(),
  })
    .index("by_key", ["key"])
    .index("by_active", ["isActive"]),

  // User achievements
  userAchievements: defineTable({
    userId: v.id("users"),
    achievementId: v.id("achievements"),
    unlockedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_achievement", ["achievementId"]),

  // User activity streaks
  userStreaks: defineTable({
    userId: v.id("users"),
    action: v.string(),
    count: v.number(),
    lastActionAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_action", ["action"]),

  // Security events for audit trail
  securityEvents: defineTable({
    userId: v.optional(v.id("users")),
    eventType: v.string(),
    severity: v.union(v.literal("info"), v.literal("warning"), v.literal("critical")),
    details: v.object({
      action: v.optional(v.string()),
      resource: v.optional(v.string()),
      metadata: v.optional(v.any()),
    }),
    ipAddress: v.optional(v.string()),
    userAgent: v.optional(v.string()),
    timestamp: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_event_type", ["eventType"])
    .index("by_severity", ["severity"])
    .index("by_timestamp", ["timestamp"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});

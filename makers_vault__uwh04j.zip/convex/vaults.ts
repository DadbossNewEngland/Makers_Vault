import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get all active vaults with creator info
export const list = query({
  args: {
    limit: v.optional(v.number()),
    search: v.optional(v.string()),
    creatorId: v.optional(v.id("creators")),
  },
  handler: async (ctx, args) => {
    const { limit = 20, search, creatorId } = args;

    let vaults;

    if (search) {
      vaults = await ctx.db
        .query("vaults")
        .withSearchIndex("search_vaults", (q) =>
          q.search("title", search).eq("isActive", true)
        )
        .take(limit);
    } else if (creatorId) {
      vaults = await ctx.db
        .query("vaults")
        .withIndex("by_creator", (q) => q.eq("creatorId", creatorId))
        .take(limit);
    } else {
      vaults = await ctx.db
        .query("vaults")
        .withIndex("by_active", (q) => q.eq("isActive", true))
        .order("desc")
        .take(limit);
    }

    // Enrich with creator data and subscription counts
    const enrichedVaults = await Promise.all(
      vaults.map(async (vault) => {
        const creator = await ctx.db.get(vault.creatorId);
        const subscriberCount = await ctx.db
          .query("vaultSubscriptions")
          .withIndex("by_vault", (q) => q.eq("vaultId", vault._id))
          .filter((q) => q.eq(q.field("status"), "active"))
          .collect()
          .then((subs) => subs.length);

        const libraryCount = await ctx.db
          .query("libraries")
          .withIndex("by_vault", (q) => q.eq("vaultId", vault._id))
          .collect()
          .then((libs) => libs.length);

        return {
          ...vault,
          creator,
          subscriberCount,
          libraryCount,
        };
      })
    );

    return enrichedVaults;
  },
});

// Get vault details with full content structure
export const getById = query({
  args: { vaultId: v.id("vaults") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    const vault = await ctx.db.get(args.vaultId);
    
    if (!vault || !vault.isActive) {
      return null;
    }

    const creator = await ctx.db.get(vault.creatorId);
    const libraries = await ctx.db
      .query("libraries")
      .withIndex("by_vault", (q) => q.eq("vaultId", vault._id))
      .collect();

    // Get content for each library
    const librariesWithContent = await Promise.all(
      libraries.map(async (library) => {
        const content = await ctx.db
          .query("content")
          .withIndex("by_library", (q) => q.eq("libraryId", library._id))
          .filter((q) => q.eq(q.field("isActive"), true))
          .collect();

        return {
          ...library,
          content,
        };
      })
    );

    // Check if user is subscribed
    let isSubscribed = false;
    if (userId) {
      const subscription = await ctx.db
        .query("vaultSubscriptions")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .filter((q) => 
          q.and(
            q.eq(q.field("vaultId"), vault._id),
            q.eq(q.field("status"), "active"),
            q.gt(q.field("expiresAt"), Date.now())
          )
        )
        .first();
      
      isSubscribed = !!subscription;
    }

    return {
      ...vault,
      creator,
      libraries: librariesWithContent,
      isSubscribed,
    };
  },
});

// Create a new vault (creators only)
export const create = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    subscriptionPrice: v.number(),
    subscriptionType: v.union(v.literal("monthly"), v.literal("yearly"), v.literal("lifetime")),
    accessLevel: v.union(v.literal("public"), v.literal("premium"), v.literal("exclusive")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    // Check if user is a creator
    const creator = await ctx.db
      .query("creators")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!creator) {
      throw new Error("Creator profile required");
    }

    const now = Date.now();
    const vaultId = await ctx.db.insert("vaults", {
      creatorId: creator._id,
      title: args.title,
      description: args.description,
      subscriptionPrice: args.subscriptionPrice,
      subscriptionType: args.subscriptionType,
      accessLevel: args.accessLevel,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    });

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "vault_created",
      severity: "info",
      details: {
        action: "create_vault",
        resource: vaultId,
        metadata: { title: args.title },
      },
      timestamp: now,
    });

    return vaultId;
  },
});

// Subscribe to a vault
export const subscribe = mutation({
  args: {
    vaultId: v.id("vaults"),
    stripeSubscriptionId: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const vault = await ctx.db.get(args.vaultId);
    if (!vault || !vault.isActive) {
      throw new Error("Vault not found or inactive");
    }

    // Check for existing active subscription
    const existingSubscription = await ctx.db
      .query("vaultSubscriptions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => 
        q.and(
          q.eq(q.field("vaultId"), args.vaultId),
          q.eq(q.field("status"), "active")
        )
      )
      .first();

    if (existingSubscription) {
      throw new Error("Already subscribed to this vault");
    }

    // Calculate expiration based on subscription type
    const now = Date.now();
    let expiresAt: number;
    
    switch (vault.subscriptionType) {
      case "monthly":
        expiresAt = now + (30 * 24 * 60 * 60 * 1000); // 30 days
        break;
      case "yearly":
        expiresAt = now + (365 * 24 * 60 * 60 * 1000); // 365 days
        break;
      case "lifetime":
        expiresAt = now + (100 * 365 * 24 * 60 * 60 * 1000); // 100 years
        break;
    }

    const subscriptionId = await ctx.db.insert("vaultSubscriptions", {
      userId,
      vaultId: args.vaultId,
      status: "active",
      stripeSubscriptionId: args.stripeSubscriptionId,
      expiresAt,
      createdAt: now,
    });

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "vault_subscription",
      severity: "info",
      details: {
        action: "subscribe_vault",
        resource: args.vaultId,
        metadata: { subscriptionType: vault.subscriptionType },
      },
      timestamp: now,
    });

    return subscriptionId;
  },
});

// Get user's vault subscriptions
export const getUserSubscriptions = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const subscriptions = await ctx.db
      .query("vaultSubscriptions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect();

    // Enrich with vault and creator data
    const enrichedSubscriptions = await Promise.all(
      subscriptions.map(async (subscription) => {
        const vault = await ctx.db.get(subscription.vaultId);
        const creator = vault ? await ctx.db.get(vault.creatorId) : null;

        return {
          ...subscription,
          vault,
          creator,
        };
      })
    );

    return enrichedSubscriptions.filter(sub => sub.vault && sub.creator);
  },
});

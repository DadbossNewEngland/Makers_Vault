import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get libraries for a vault
export const getByVault = query({
  args: { vaultId: v.id("vaults") },
  handler: async (ctx, args) => {
    const libraries = await ctx.db
      .query("libraries")
      .withIndex("by_vault", (q) => q.eq("vaultId", args.vaultId))
      .order("asc")
      .collect();

    // Enrich with content count
    const enrichedLibraries = await Promise.all(
      libraries.map(async (library) => {
        const contentCount = await ctx.db
          .query("content")
          .withIndex("by_library", (q) => q.eq("libraryId", library._id))
          .filter((q) => q.eq(q.field("isActive"), true))
          .collect()
          .then((content) => content.length);

        return {
          ...library,
          contentCount,
        };
      })
    );

    return enrichedLibraries;
  },
});

// Create a new library
export const create = mutation({
  args: {
    vaultId: v.id("vaults"),
    title: v.string(),
    description: v.optional(v.string()),
    price: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    // Verify vault ownership
    const vault = await ctx.db.get(args.vaultId);
    if (!vault) {
      throw new Error("Vault not found");
    }

    const creator = await ctx.db
      .query("creators")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!creator || vault.creatorId !== creator._id) {
      throw new Error("Access denied");
    }

    // Get next order number
    const existingLibraries = await ctx.db
      .query("libraries")
      .withIndex("by_vault", (q) => q.eq("vaultId", args.vaultId))
      .collect();

    const nextOrder = existingLibraries.length;

    const libraryId = await ctx.db.insert("libraries", {
      vaultId: args.vaultId,
      title: args.title,
      description: args.description,
      price: args.price,
      order: nextOrder,
      createdAt: Date.now(),
    });

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "library_created",
      severity: "info",
      details: {
        action: "create_library",
        resource: libraryId,
        metadata: { title: args.title, vaultId: args.vaultId },
      },
      timestamp: Date.now(),
    });

    return libraryId;
  },
});

// Update library
export const update = mutation({
  args: {
    libraryId: v.id("libraries"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    price: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const library = await ctx.db.get(args.libraryId);
    if (!library) {
      throw new Error("Library not found");
    }

    // Verify ownership
    const vault = await ctx.db.get(library.vaultId);
    if (!vault) {
      throw new Error("Vault not found");
    }

    const creator = await ctx.db
      .query("creators")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!creator || vault.creatorId !== creator._id) {
      throw new Error("Access denied");
    }

    const updates: any = {};
    if (args.title !== undefined) updates.title = args.title;
    if (args.description !== undefined) updates.description = args.description;
    if (args.price !== undefined) updates.price = args.price;

    if (Object.keys(updates).length === 0) {
      return args.libraryId;
    }

    await ctx.db.patch(args.libraryId, updates);

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "library_updated",
      severity: "info",
      details: {
        action: "update_library",
        resource: args.libraryId,
        metadata: updates,
      },
      timestamp: Date.now(),
    });

    return args.libraryId;
  },
});

// Delete library
export const remove = mutation({
  args: { libraryId: v.id("libraries") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const library = await ctx.db.get(args.libraryId);
    if (!library) {
      throw new Error("Library not found");
    }

    // Verify ownership
    const vault = await ctx.db.get(library.vaultId);
    if (!vault) {
      throw new Error("Vault not found");
    }

    const creator = await ctx.db
      .query("creators")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!creator || vault.creatorId !== creator._id) {
      throw new Error("Access denied");
    }

    // Check if library has content
    const contentCount = await ctx.db
      .query("content")
      .withIndex("by_library", (q) => q.eq("libraryId", args.libraryId))
      .collect()
      .then((content) => content.length);

    if (contentCount > 0) {
      throw new Error("Cannot delete library with content. Remove content first.");
    }

    await ctx.db.delete(args.libraryId);

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "library_deleted",
      severity: "info",
      details: {
        action: "delete_library",
        resource: args.libraryId,
        metadata: { title: library.title },
      },
      timestamp: Date.now(),
    });

    return args.libraryId;
  },
});

import { mutation } from "./_generated/server";

// Seed sample data for development
export const seedSampleData = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if data already exists
    const existingCreators = await ctx.db.query("creators").collect();
    if (existingCreators.length > 0) {
      return "Sample data already exists";
    }

    const now = Date.now();

    // Create sample creators
    const creator1 = await ctx.db.insert("creators", {
      userId: "sample_user_1" as any,
      name: "Alex Thompson",
      bio: "Digital artist and 3D modeling expert. Creating stunning visual content for over 10 years.",
      verified: true,
      loyaltyBalance: 0,
      createdAt: now,
    });

    const creator2 = await ctx.db.insert("creators", {
      userId: "sample_user_2" as any,
      name: "Sarah Chen",
      bio: "Photography and video editing specialist. Passionate about teaching creative techniques.",
      verified: true,
      loyaltyBalance: 0,
      createdAt: now,
    });

    const creator3 = await ctx.db.insert("creators", {
      userId: "sample_user_3" as any,
      name: "Marcus Rodriguez",
      bio: "Music producer and sound design expert. Sharing industry secrets and production tips.",
      verified: false,
      loyaltyBalance: 0,
      createdAt: now,
    });

    // Create sample vaults
    const vault1 = await ctx.db.insert("vaults", {
      creatorId: creator1,
      title: "3D Modeling Mastery",
      description: "Learn professional 3D modeling techniques from concept to final render. Includes Blender, Maya, and industry workflows.",
      subscriptionPrice: 29.99,
      subscriptionType: "monthly",
      isActive: true,
      accessLevel: "premium",
      createdAt: now,
      updatedAt: now,
    });

    const vault2 = await ctx.db.insert("vaults", {
      creatorId: creator2,
      title: "Photography Fundamentals",
      description: "Master the art of photography with comprehensive tutorials covering composition, lighting, and post-processing.",
      subscriptionPrice: 199.99,
      subscriptionType: "yearly",
      isActive: true,
      accessLevel: "public",
      createdAt: now,
      updatedAt: now,
    });

    const vault3 = await ctx.db.insert("vaults", {
      creatorId: creator3,
      title: "Music Production Secrets",
      description: "Exclusive content on music production, mixing, and mastering. Learn the techniques used by top producers.",
      subscriptionPrice: 499.99,
      subscriptionType: "lifetime",
      isActive: true,
      accessLevel: "exclusive",
      createdAt: now,
      updatedAt: now,
    });

    const vault4 = await ctx.db.insert("vaults", {
      creatorId: creator1,
      title: "Advanced Rendering Techniques",
      description: "Deep dive into photorealistic rendering with advanced lighting, materials, and optimization techniques.",
      subscriptionPrice: 39.99,
      subscriptionType: "monthly",
      isActive: true,
      accessLevel: "premium",
      createdAt: now,
      updatedAt: now,
    });

    const vault5 = await ctx.db.insert("vaults", {
      creatorId: creator2,
      title: "Portrait Photography Workshop",
      description: "Specialized course focusing on portrait photography, from studio setups to natural light techniques.",
      subscriptionPrice: 149.99,
      subscriptionType: "yearly",
      isActive: true,
      accessLevel: "public",
      createdAt: now,
      updatedAt: now,
    });

    const vault6 = await ctx.db.insert("vaults", {
      creatorId: creator3,
      title: "Electronic Music Masterclass",
      description: "Learn to create professional electronic music tracks with industry-standard tools and techniques.",
      subscriptionPrice: 79.99,
      subscriptionType: "monthly",
      isActive: true,
      accessLevel: "premium",
      createdAt: now,
      updatedAt: now,
    });

    // Create sample libraries
    const library1 = await ctx.db.insert("libraries", {
      vaultId: vault1,
      title: "Beginner Fundamentals",
      description: "Start your 3D journey with basic concepts and tools",
      price: 19.99,
      order: 0,
      createdAt: now,
    });

    const library2 = await ctx.db.insert("libraries", {
      vaultId: vault1,
      title: "Character Modeling",
      description: "Learn to create detailed 3D characters",
      price: 39.99,
      order: 1,
      createdAt: now,
    });

    const library3 = await ctx.db.insert("libraries", {
      vaultId: vault2,
      title: "Camera Basics",
      description: "Understanding your camera and its settings",
      price: 24.99,
      order: 0,
      createdAt: now,
    });

    // Create sample content
    await ctx.db.insert("content", {
      libraryId: library1,
      creatorId: creator1,
      title: "Introduction to 3D Modeling",
      description: "Your first steps into the world of 3D modeling",
      videoUrl: "https://example.com/video1.mp4",
      price: 9.99,
      duration: 1800,
      isActive: true,
      viewCount: 245,
      createdAt: now,
    });

    await ctx.db.insert("content", {
      libraryId: library1,
      creatorId: creator1,
      title: "Understanding 3D Space",
      description: "Learn to navigate and work in 3D environments",
      videoUrl: "https://example.com/video2.mp4",
      price: 12.99,
      duration: 2400,
      isActive: true,
      viewCount: 189,
      createdAt: now,
    });

    await ctx.db.insert("content", {
      libraryId: library2,
      creatorId: creator1,
      title: "Character Design Principles",
      description: "Essential principles for creating compelling characters",
      videoUrl: "https://example.com/video3.mp4",
      price: 19.99,
      duration: 3600,
      isActive: true,
      viewCount: 156,
      createdAt: now,
    });

    await ctx.db.insert("content", {
      libraryId: library3,
      creatorId: creator2,
      title: "Camera Settings Explained",
      description: "Master aperture, shutter speed, and ISO",
      videoUrl: "https://example.com/video4.mp4",
      price: 14.99,
      duration: 2700,
      isActive: true,
      viewCount: 312,
      createdAt: now,
    });

    // Create sample achievements
    await ctx.db.insert("achievements", {
      key: "first_purchase",
      title: "First Treasure",
      description: "Made your first content purchase",
      points: 100,
      isActive: true,
      createdAt: now,
    });

    await ctx.db.insert("achievements", {
      key: "vault_explorer",
      title: "Vault Explorer",
      description: "Subscribed to your first vault",
      points: 250,
      isActive: true,
      createdAt: now,
    });

    await ctx.db.insert("achievements", {
      key: "treasure_collector",
      title: "Treasure Collector",
      description: "Collected 10 different treasures",
      points: 500,
      isActive: true,
      createdAt: now,
    });

    return "Sample data seeded successfully!";
  },
});

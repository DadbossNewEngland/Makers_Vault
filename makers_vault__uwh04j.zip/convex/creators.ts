import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get creator profile by user ID
export const getByUserId = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const userId = args.userId || await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const creator = await ctx.db
      .query("creators")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!creator) {
      return null;
    }

    // Get creator stats
    const vaultCount = await ctx.db
      .query("vaults")
      .withIndex("by_creator", (q) => q.eq("creatorId", creator._id))
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect()
      .then((vaults) => vaults.length);

    const totalSubscribers = await ctx.db
      .query("vaultSubscriptions")
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect()
      .then(async (subscriptions) => {
        const creatorVaults = await ctx.db
          .query("vaults")
          .withIndex("by_creator", (q) => q.eq("creatorId", creator._id))
          .collect();
        
        const vaultIds = creatorVaults.map(v => v._id);
        return subscriptions.filter(sub => vaultIds.includes(sub.vaultId)).length;
      });

    return {
      ...creator,
      vaultCount,
      totalSubscribers,
      totalRevenue: 0, // TODO: Calculate from purchases
      averageRating: 4.8, // TODO: Calculate from reviews
    };
  },
});

// Create creator profile
export const create = mutation({
  args: {
    name: v.string(),
    bio: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    // Check if creator profile already exists
    const existingCreator = await ctx.db
      .query("creators")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (existingCreator) {
      throw new Error("Creator profile already exists");
    }

    const now = Date.now();
    const creatorId = await ctx.db.insert("creators", {
      userId,
      name: args.name,
      bio: args.bio,
      verified: false,
      loyaltyBalance: 0,
      createdAt: now,
    });

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "creator_profile_created",
      severity: "info",
      details: {
        action: "create_creator_profile",
        resource: creatorId,
        metadata: { name: args.name },
      },
      timestamp: now,
    });

    return creatorId;
  },
});

// Update creator profile
export const update = mutation({
  args: {
    name: v.optional(v.string()),
    bio: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const creator = await ctx.db
      .query("creators")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!creator) {
      throw new Error("Creator profile not found");
    }

    const updates: any = {};
    if (args.name !== undefined) updates.name = args.name;
    if (args.bio !== undefined) updates.bio = args.bio;

    if (Object.keys(updates).length === 0) {
      return creator._id;
    }

    await ctx.db.patch(creator._id, updates);

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "creator_profile_updated",
      severity: "info",
      details: {
        action: "update_creator_profile",
        resource: creator._id,
        metadata: updates,
      },
      timestamp: Date.now(),
    });

    return creator._id;
  },
});

// List all creators with stats
export const list = query({
  args: {
    limit: v.optional(v.number()),
    verified: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { limit = 20, verified } = args;

    let creators;
    
    if (verified !== undefined) {
      creators = await ctx.db
        .query("creators")
        .withIndex("by_verified", (q) => q.eq("verified", verified))
        .take(limit);
    } else {
      creators = await ctx.db.query("creators").take(limit);
    }



    // Enrich with stats
    const enrichedCreators = await Promise.all(
      creators.map(async (creator) => {
        const vaultCount = await ctx.db
          .query("vaults")
          .withIndex("by_creator", (q) => q.eq("creatorId", creator._id))
          .filter((q) => q.eq(q.field("isActive"), true))
          .collect()
          .then((vaults) => vaults.length);

        const totalSubscribers = await ctx.db
          .query("vaultSubscriptions")
          .filter((q) => q.eq(q.field("status"), "active"))
          .collect()
          .then(async (subscriptions) => {
            const creatorVaults = await ctx.db
              .query("vaults")
              .withIndex("by_creator", (q) => q.eq("creatorId", creator._id))
              .collect();
            
            const vaultIds = creatorVaults.map(v => v._id);
            return subscriptions.filter(sub => vaultIds.includes(sub.vaultId)).length;
          });

        return {
          ...creator,
          vaultCount,
          totalSubscribers,
          totalRevenue: 0, // TODO: Calculate from purchases
          averageRating: 4.8, // TODO: Calculate from reviews
        };
      })
    );

    return enrichedCreators;
  },
});

import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get content with access control
export const getById = query({
  args: { contentId: v.id("content") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    const content = await ctx.db.get(args.contentId);
    
    if (!content || !content.isActive) {
      return null;
    }

    const library = await ctx.db.get(content.libraryId);
    const vault = library ? await ctx.db.get(library.vaultId) : null;
    const creator = content ? await ctx.db.get(content.creatorId) : null;

    if (!library || !vault || !creator || !vault.isActive) {
      return null;
    }

    // Check access permissions
    let hasAccess = false;
    let isPurchased = false;

    if (userId) {
      // Check direct purchase
      const purchase = await ctx.db
        .query("purchases")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .filter((q) => q.eq(q.field("contentId"), content._id))
        .first();

      isPurchased = !!purchase;

      // Check vault subscription
      const subscription = await ctx.db
        .query("vaultSubscriptions")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .filter((q) => 
          q.and(
            q.eq(q.field("vaultId"), vault._id),
            q.eq(q.field("status"), "active"),
            q.gt(q.field("expiresAt"), Date.now())
          )
        )
        .first();

      hasAccess = isPurchased || !!subscription;
    }

    return {
      ...content,
      library,
      vault,
      creator,
      hasAccess,
      isPurchased,
    };
  },
});

// Purchase content
export const purchase = mutation({
  args: {
    contentId: v.id("content"),
    stripePaymentId: v.string(),
    amount: v.number(),
    ipAddress: v.string(),
    deviceFingerprint: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const content = await ctx.db.get(args.contentId);
    if (!content || !content.isActive) {
      throw new Error("Content not found or inactive");
    }

    // Verify price matches
    if (content.price !== args.amount) {
      throw new Error("Price mismatch");
    }

    // Check for duplicate purchase
    const existingPurchase = await ctx.db
      .query("purchases")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("contentId"), args.contentId))
      .first();

    if (existingPurchase) {
      throw new Error("Content already purchased");
    }

    const now = Date.now();

    // Calculate loyalty points (10 points per dollar spent)
    const loyaltyPointsEarned = Math.floor(args.amount * 10);

    // Create purchase record
    const purchaseId = await ctx.db.insert("purchases", {
      userId,
      contentId: args.contentId,
      amount: args.amount,
      stripePaymentId: args.stripePaymentId,
      loyaltyPointsEarned,
      ipAddress: args.ipAddress,
      deviceFingerprint: args.deviceFingerprint,
      createdAt: now,
    });

    // Update user loyalty balance
    const user = await ctx.db.get(userId);
    if (user) {
      const creator = await ctx.db
        .query("creators")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .first();
      
      if (creator) {
        await ctx.db.patch(creator._id, {
          loyaltyBalance: creator.loyaltyBalance + loyaltyPointsEarned,
        });
      }
    }

    // Create point transaction record
    await ctx.db.insert("pointTransactions", {
      userId,
      purchaseId,
      amount: loyaltyPointsEarned,
      multiplier: 10,
      source: "content_purchase",
      hash: `${purchaseId}_${now}`,
      createdAt: now,
    });

    // Generate treasure rewards
    await generateTreasureRewards(ctx, userId, purchaseId, args.amount);

    // Log security event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "content_purchase",
      severity: "info",
      details: {
        action: "purchase_content",
        resource: args.contentId,
        metadata: { 
          amount: args.amount,
          stripePaymentId: args.stripePaymentId 
        },
      },
      ipAddress: args.ipAddress,
      timestamp: now,
    });

    return purchaseId;
  },
});

// Generate secure video URL for purchased content
export const getSecureVideoUrl = mutation({
  args: { contentId: v.id("content") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const content = await ctx.db.get(args.contentId);
    if (!content || !content.isActive || !content.videoUrl) {
      throw new Error("Content not found or no video available");
    }

    // Verify access
    const hasAccess = await verifyContentAccess(ctx, userId, args.contentId);
    if (!hasAccess) {
      throw new Error("Access denied");
    }

    // Log access event
    await ctx.db.insert("securityEvents", {
      userId,
      eventType: "content_access",
      severity: "info",
      details: {
        action: "access_video",
        resource: args.contentId,
      },
      timestamp: Date.now(),
    });

    // In a real implementation, you would generate a signed URL here
    // For now, return the video URL (in production, this should be a time-limited signed URL)
    return content.videoUrl;
  },
});

// Helper function to verify content access
async function verifyContentAccess(ctx: any, userId: string, contentId: string): Promise<boolean> {
  // Check direct purchase
  const purchase = await ctx.db
    .query("purchases")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .filter((q: any) => q.eq(q.field("contentId"), contentId))
    .first();

  if (purchase) return true;

  // Check vault subscription
  const content = await ctx.db.get(contentId);
  if (!content) return false;

  const library = await ctx.db.get(content.libraryId);
  if (!library) return false;

  const subscription = await ctx.db
    .query("vaultSubscriptions")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .filter((q: any) => 
      q.and(
        q.eq(q.field("vaultId"), library.vaultId),
        q.eq(q.field("status"), "active"),
        q.gt(q.field("expiresAt"), Date.now())
      )
    )
    .first();

  return !!subscription;
}

// Helper function to generate treasure rewards
async function generateTreasureRewards(ctx: any, userId: string, purchaseId: string, amount: number) {
  const now = Date.now();
  const treasures = [];

  // Base treasure for any purchase
  treasures.push({
    userId,
    type: "coin" as const,
    rarity: "common" as const,
    value: Math.floor(amount),
    mintSignature: `${purchaseId}_coin_${now}`,
    purchaseId,
    earnedFrom: "purchase",
    mintedAt: now,
  });

  // Bonus treasures based on purchase amount
  if (amount >= 50) {
    treasures.push({
      userId,
      type: "gem" as const,
      rarity: "rare" as const,
      value: Math.floor(amount * 0.1),
      mintSignature: `${purchaseId}_gem_${now}`,
      purchaseId,
      earnedFrom: "purchase_bonus",
      mintedAt: now,
    });
  }

  if (amount >= 100) {
    treasures.push({
      userId,
      type: "artifact" as const,
      rarity: "epic" as const,
      value: Math.floor(amount * 0.05),
      mintSignature: `${purchaseId}_artifact_${now}`,
      purchaseId,
      earnedFrom: "purchase_bonus",
      mintedAt: now,
    });
  }

  // Insert all treasures
  for (const treasure of treasures) {
    await ctx.db.insert("treasures", treasure);
  }
}
